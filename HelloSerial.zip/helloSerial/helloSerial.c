
/* Testing out Serial.  Doesn't really do much yet. */

#include <avr/io.h>		/* Defines pins, ports, etc */

#define F_CPU 1000000UL	      /* Sets up the chip speed for delay.h */
#include <util/delay.h>		/* Functions to waste time */

#define BAUDRATE  4800
#include "USART48.h"		/* uses BAUDRATE, so define it first */

int main(void){
  
  uint8_t i, letter;
  
  initUART();
  sayOK();
  
  while(1){
    for (letter = 'A'; letter <= 'Z'; letter++){
      transmitByte(letter);
      
      _delay_ms(100);
      _delay_ms(100);
    }
    transmitByte('\n');

    for (i=9; i>0; i--){

      transmitByte('0'+i);
      transmitByte(':');
      transmitByte(' ');
      
      letter = receiveByte();
      transmitByte(letter);
      transmitByte('\n');
    }
  }
}
