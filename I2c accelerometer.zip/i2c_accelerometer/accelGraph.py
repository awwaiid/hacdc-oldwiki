#!/usr/bin/env python

import serial

serialPort = serial.Serial('/dev/ttyUSB1', 57600, timeout=10)

def readValue(serialPort):
    serialPort.flushInput()
    return(ord(serialPort.read()))

def plotAccel():
    pass
    

    



  

